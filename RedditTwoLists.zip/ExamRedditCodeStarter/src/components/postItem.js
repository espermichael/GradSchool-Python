import React from 'react';

const PostItem = (props) => {

    const post = props.post;
    const thumbnail = post.thumbnail;
    const created = post.created;
    const url = post.url;
    const title = post.title;
   
     console.log(post);
    //const imageUrl = video.snippet.thumbnails.default.url;
    
return (
    
    <li  className="list-group-item">        
    <div className="post-list-media">
        <div className = "media-left">
            <img className="media-object" src = {thumbnail}/>
        </div>
        <div className = "media-body">
            <div className="media-heading"><a href={url} target="_blank">{title}</a></div>
        </div>
    </div>
    </li>
)};


export default PostItem;


