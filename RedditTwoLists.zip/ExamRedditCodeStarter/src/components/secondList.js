import React from 'react';
import ReactDom from 'react-dom';
import PostItem from './postItem';

const SecondList = (props) => {


    const listItems = props.funnys.map((funny) => {
        let link = "http://www.reddit.com";
     return (
         <PostItem
            key= { funny.data.created }
            post = { funny.data }
         />
        
    );

    });

    return (
        <ul className="col-md-6 list-group">
        { listItems }
        </ul>
    );
};

export default SecondList;