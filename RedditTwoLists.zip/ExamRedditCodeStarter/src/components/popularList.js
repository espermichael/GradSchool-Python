import React from 'react';
import ReactDom from 'react-dom';
import PostItem from './postItem';

const PopularList = (props) => {


    const listItems = props.populars.map((popular) => {
        let link = "http://www.reddit.com";
     return (
         <PostItem
            key= { popular.data.created }
            post = { popular.data }
         />
        
    );

    });

    return (
        <ul className="col-md-6 list-group">
        { listItems }
        </ul>
    );
};

export default PopularList;