import React from 'react';
import ReactDOM from 'react-dom';

const Header = () => {
    return (
    
    <div>

            <h1>Reddit lists</h1>
            <br />
    <div className="popularHeader">
              <h1> Popular List </h1>
    </div>
    <div className="anotherHeader">              
               <h1> Funny List </h1>
    </div>
    </div>
    )}

export default Header;
