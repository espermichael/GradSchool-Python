import React from 'react';
import ReactDOM from 'react-dom';
import PopularList from './components/popularList';
import SecondList from './components/secondList';
import Header from './components/header';



class App extends React.Component{

    constructor(props){
        super(props);
        this.state={
            populars:[],funnys:[]
        };
    }

    componentDidMount() {
        this.popularData();
        this.funnyData();
    }

    render(){

        return(
            <div> 
                <Header />
                <PopularList populars={this.state.populars} />
                <SecondList funnys={this.state.funnys} />
            </div>
            
        );
    }

    popularData = () => {
            fetch("https://www.reddit.com/r/popular.json")
            .then(function(response)
            { return response.json(); })
            .then( (data) =>
                {
                //console.log(data.data.children);
                this.setState({
                    populars: data.data.children,
                }
            )
            });
    }

    funnyData = () => {
        fetch("https://www.reddit.com/r/funny.json")
        .then(function(response)
        { return response.json(); })
        .then( (data) =>
            {
            //console.log(data.data.children);
            this.setState({
                funnys: data.data.children,
            }
        )
        });
}
}

ReactDOM.render(<App />, document.querySelector('.container'));
